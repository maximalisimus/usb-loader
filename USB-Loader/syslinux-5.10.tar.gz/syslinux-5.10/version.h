#define VERSION 5.10
#define VERSION_STR "5.10"
#define VERSION_MAJOR 5
#define VERSION_MINOR 10
#define YEAR 2013
#define YEAR_STR "2013"
