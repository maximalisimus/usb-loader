#ifndef _H_FAT_
#define _H_FAT_

#define MSDOS_SUPER_MAGIC       0x4d44          /* MD */
/* The rest is defined in syslxint.h */

#endif
