﻿
regsvr32 "C:\Windows\System32\msimtf.dll"

regsvr32 "C:\Windows\System32\msctf.dll"






Regsvr32.exe /u msimtf.dll

Regsvr32.exe /u msctf.dll


