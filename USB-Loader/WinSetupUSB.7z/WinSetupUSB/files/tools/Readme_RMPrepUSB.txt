RM Utilities for bootable storage devices

(c)2008/2009 RM Education plc All right reserved

Disclaimer
==========

These utilities are for private use only.
Unauthorised distribution prohibited.
Available at www.boot-land.net or www.rm.com/support only.
These utilities are provided 'as is' for private use - with no support except through boot-land forum or for RM customers.
Please contact support@rm.com for other enquiries.

Thanks to 'online' for idea of using a 2nd partition to make some BIOSes boot from a UFD as a hard disk
Thanks to 'wimb', 'jaclaz', 'fuwi' and others on www.boot-land.net forum for help with final tweaks.


Information
===========

All .exe files run under Windows XP, Vista, 2003 or WinPE (WinPE requires wmi component).
Some require the MSVBVM60.dll (included) which should be present in the same folder or in \windows\system32.


History
=======
RMBootSect v1.2 and RMPartUSB 1.9.72 have a fix for NTLDR FAT32 bootsector 12 missing, which mean't that FAT32 XP/BartPE systems may not boot.


Programs
========

Command line programs
---------------------
RMBootSect.exe v1.2.00  - changes a volumes bootsector code (similar to Microsoft Bootsect.exe but can run under XP)
RMPartUSB.exe  v1.9.72  - wipes, partitions and formats any USB storage device and makes it bootable

Windows GUI programs
--------------------
RMPrepUSB.exe  v1.9.70  - user-friendly GUI for RMPartUSB (folder browse button not supported under WinPE).
RMFormat.exe   v1.0.0   - formats USB volumes under XP/Vista FAT16/FAT32/NTFS - uses Windows format API FormatEx

Read .txt files for more information and also use the help buttons.
 

RMPartUSB can be used to make large bootable FAT32 volumes on a USB disk drive (much larger than 32GB allowed by Windows).
RMPartUSB supports bootable MS-DOS, FreeDOS, XP/WinPEv1 and Vista/WinPEv2 FAT16/FAT32/NTFS volumes (except NTFS+DOS is not supported!)


Look on the RM Knowledge Library at www.rm.com/support for the most recent versions.

RMPrepUSB and RMPartUSB are for private use only (not commercial use) and must not be redistributed without permission from the author. The latest versions can be obtained from www.rm.com/support. Enquiries to support@rm.com.





