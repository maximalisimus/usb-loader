=================================================================================================================
Author:         Ilko
Version: 		0.2.3
Credits: jaclaz, cdob, wimb and porear from MSFN forum for their continuous help and work on Installing XP from USB, without who this wouldn't have happened, 
as well as to everyone, who contributed to the project with ideas, requests or feedback.
 
Thanks to UglyBob, ptrex, SmOke_N, aec and ezzetabi from AutoIt forum for their excellent AutoIt script examples, parts of which were used.
Thanks to Anton Bassov for his dummydisk.sys driver and help for reverting it's behaviour to rdummy.sys, which makes USB fixed disks to be seen as removable.
Thanks to Ercofrafrom msfn.org forum for ideas to fix some of the issues with unattended section in WINNT.SIF isung fake setup.exe.
Thanks to Driver Packs team and OverFlow for letting me use their version of fake Setup.exe, original idea and authors- schalti, Pyron, a06lp and iLE
Thanks to Bean123, who helped with grubinst.exe and touchdrv.exe and Tynibit for his excellent support with grub4dos issues.
And last but not least credits to creators of all tools, which were used in this project- Grub4DOS, PEtoUSB, HP USB format utility, HDHacker, SysLinux, binifix.cmd(did I mention Jaclaz, cdob and wimb?), QEMU, DRVLoad
,sync.exe and spdrvscn from Vernalex, Nicholas Dille for start64.exe.

Thanks to Steve6375 from boot-land.net forums making RMPrepUSB package and letting me include and redistribute it.

The program is released "as is" and is free for redistribution, use or changes AS LONG AS original author, credits part and link to the support forum-
http://www.msfn.org/board/Install-XP-from-USB-f157.html 
are CLEARLY mentioned.

Author does not take any responsibility for use or misuse of the program!
=================================================================================================================

How to start-
1. First make sure you have a properly formatted USB disk or flash media.
It must have a MBR and an active partition set.

a) USB flash media- format it with RMPrepUSB selecting "Boot as HDD" and "XP bootable" options.
Note that it will DELETE all partitions. NTFS is reported faster on some systems, your USB stick parameters are also factor. 
Whereas NTFS generally is not recommended for USB flash media, if you are not planning excessive usage, but rather occasional installs from it, then it should be safe to use it as long as you can boot from it.

There is another way to format USB flash media- to use filter driver, such as Hitachi microdrive filter driver or dummydisk.sys (included, look in FILES\MULTIpartitionUSBstick folder). Using such driver will 'make' your stick to appear to Windows as fixed disk. In this case, when formatting Windows will write MBR on in with partition information. 
You may now use Disk management console, or third party programs to make multiple partitions and format them as you desire.

NTFS performs way faster on some systems, or with some USB sticks. However, keep in mind that depending on usage and USB stick quality, it may "wear it out" quicker.

Look here foe a quick speed comparison and how faster NTFS is:
http://www.msfn.org/board/index.php?showtopic=125116

!!!Make sure you set an active partition, either from Disk management, or from your favourite external program if you don't have such!!!
!!!Use primary partitions when placing Windows based sources!!!
!!!Usew first partition when copying Windows XP/2003/2000 Setup!!!

b) USB hard disk- format it from within Windows and make sure you set active partition!!!

In both cases USB boot is not guaranteed! That depends on your BIOS/motherboard, how disk is formatted and what file system etc.
In general FAT16 is the best bet for compatibility, next is FAT32, then NTFS. In some cases different format tools may set improper geometry.
Look here for some detailed answers:
http://home.graffiti.net/jaclaz:graffiti.net/Projects/USB/USBstick.html
http://home.graffiti.net/jaclaz:graffiti.net/Projects/USB/USBfaqs.html

2. Select your sources

a) Windows- select the folder, which contains I386/AMD64 folders. Do NOT select folder I386 itself!

!!!If you used Nlite to slim it down, option "Operating System Options-->Manual Install and Upgrade for removal" must NOT be selected. This is crucial part.!!!

Optionally:
b) BartPE/WinBuilder/UBCD4Win/WinFLPC- select the folder, which contains I386 folder.
!!!In case of WinFLPC keep in mind that BOOT.INI on target disk wll be set incorrectly!!! In order to start it for a first time, either edit in BOOT.INI disk(z) to disk(z-1) from BartPE for example, or add this to menu.lst on the active partition of the USB disk
####
title Start WinFLPC
map (hd1) (hd0)
map --hook
rootnoverify (hd0,0)
chainloader /ntldr
###
Above example assumes WinFLPC is on first partition of your first internal disk. Ammend accordingly.
Once in WinFLPC, edit BOOT.INI on the internal disk as was mentioned above:
multi(0)disk(0)rdisk(1)partition(1)\WINDOWS="Microsoft Windows FPLC" /FASTDETECT  to
multi(0)disk(0)rdisk(0)partition(1)\WINDOWS="Microsoft Windows FPLC" /FASTDETECT

c) Vista / Windows 7 setup- select the folder with BOOT and SOURCES folders.
d) PartedMagic- where ISO file pmagic-3.X.iso is. You need to extract pmagic-grub4dos-3.X.iso.zip somewhere and point to its location. 
To get PartedMagic: http://partedmagic.com/

Use this option to add other ISOs, which can boot using grub4dos CD emulation. Here you can find number of examples:
http://www.boot-land.net/forums/index.php?showtopic=5041

e) SysLinux- select your Linux distro, which boots off SysLinux. All files/folders will be copied. A file(syslin.dat), containing Syslinux bootsector will be made, and an entry in the boot menu (menu.lst), pointing to that file will be made. In case you do not select anything only syslin.dat and ldlinux.sys will be copied, plus entry in menu.lst.
!!! Make sure you have not already added another source, which contains the same folders in root as the ones from Vista, UBCD4Win etc. The program will NOT overwrite files/folders.!!!
!!! SysLinux cannot be started from NTFS formatted partition !!!
3. Select target disk from the drop-down menu. Windows Setup can be started only from the first partition on the disk! It does not have to be active. Sorry, this is limitation from Microsoft- in case of removable USB disk, it can't read any partition than first.
If your USB disk is not shown then:
a) It's not inserted
b) It does NOT have an active partition
c) It's NOT formatted in FAT16,FAT32 or NTFS
d) The program has a bug :) Please report details.

Optional settings:
4. Force target disk type(FIXED/REMOVABLE)- usually the program will detect that for you. Force selection only if you are using filter driver as above mentioned dummydisk.sys or Hitachi microdrive filter driver. Or if for some reason the program did not detect it correctly. This is an important part when installing Windows XP/2kX from USB hard disks, or USB flash media, which is seen by Windows as FIXED.

5. Copy Setup boot files only- this option will copy just a minimal set of files (7-12MB), necessary for the first part(Text mode) of the setup. 
Use to test how your USB disk boots, before copying the main part. 

!!!DO NOT continue setup, you have to stop when you see the list of hard disks detected!!!

6. Test in QEMU- this will launch QEMU virtual machine, which will use your USB disk as it's internal disk. You may use that as a basic test how the build went.
Note that this not guarantees you the same result on real hardware.
!!! Currently it's setup to use 256MB RAM when started. Make sure you have at least that amount + some extra RAM available!!!
!!!USE AT OWN RISK. DO NOT PERFORM WRITE OPERATIONS WHILE IN QEMU!!!

7. BOOT.INI adjustments
a) First field is the directory name, where Windows will be installed to. 
b) Disk Nr.- on which of your disks Windows will be installed to. For example if you have two internal disks, first is disk 0, second is disk 1.
c) Partition number- in which partition of the above selected disk Windows will be installed to.
d) Additional entries in BOOT.INI- as above, but creates additional lines in BOOT.INI with the specified data. Use it if you plan to install Windows to disks/partition/directories other than the ones above.

This data will be used to create BOOT.INI on the USB disk, with the correct settings. It will be used to start the second part (GUI mode) of setup, AND to start Windows for first time, still using the USB disk as boot device.

!!!Make sure the above entries are correct, otherwise you will get error messages like "HAL.DLL/NTOSKRNL.EXE was not found"
I need to stress on that- make sure BOOT.INI data is correct, and DO NOT UNPLUG the USB disk until you enter first normal Windows desktop.

8) Press GO button, you have guessed that :)

You have 2 steps, in both USB stick is your boot device (change that preferably in BIOS):
-Text mode part of setup
-GUI mode part of setup

!!!If your source is NOT Windows XP2 SP2 or SP3, some of the compressed files in ~LS folder will be deleted during the first part(Text mode). To make another install from this disk you have to copy the missing files, use the program for this purpose and follow the prompts when it finds existing setup folders.!!!

!!!If you are getting Blue screen with 0x0000007B error during start of Text mode setup or BartPE/WinBuilder..., read A3:

http://www.msfn.org/board/FAQs-t116766.html

and make sure you have a driver for your mass storage (SATA/AHCI/SCSI/RAID) controller in your source.

=======================================================================================

Some advanced features of the program:
- supports multiple Windows XP/2kX sources in the same partition (up to 10). Existing folders ~BT and ~LS and TXTSETUP.SIF will be renamed, and SETUPLDR.BIN and SETUPDD.SYS patched against the new names. Checksum checks are also corrected.
- supports booting BartPE/WinBulder/UBCD4Win/WinFLPC from different partitions. Multiple BartPE for example in the SAME partition are NOT supported. Neither is the mix of them on a single partition.
- supports booting Vista / Windows 7 setup from different partitions. Multiple Vista/7 sources in the SAME partition are NOT supported. Place your second Vista setup in another partition. It can be placed on any primary partition.
- UBCD4Win boot menu is adjusted to boot from the selected partition. It can be placed on any primary partition.
- if Windows setup folders (~BT and ~LS) and txtsetup.sif coexist in the same partition as BartPE/WinBuilder/UNCD4Win/WinFLPC, SETUPLDR.BIN of the latter is patched not to use txtsetup.sif in root. Checksum checks are also corrected.
- grub4dos is the main bootloader/manager. Without it's advanced features, multiple partitions will not be easily achieved. 
Bootsector loading GRLDR is installed in the active partition of the selected disk. Hence the requirement for active partition and MBR.
- detailed log file is created in the folder, where program is executed from. Use it for troubleshooting. Upon next execution if log file is found, it's compressed in MS cab format, removed to BACKUPS folder and renamed with current DATE/TIME stamp.
- upon installing grub4dos bootsector, backup of MBR and bootsector with DATE/TIME stamp are placed in BACKUPS folder. Us it in case something goes wrong.
- if in Windows source folder winnt.sif or unattend.txt are found they will be used as answer file. Section UNATTENDED will be temporarily removed, only for the Text part of setup, and before start of GUI mode it will be merged back. PRESETUP.CMD is used for this purpose.
- Windows source will be copied as follows- 
		everything in I386/AMD64 folders. 
		BTS drivers pack OEM folder
		$OEM$ folder
		CMPNENTS folder
		PRINTERS folder
	If you want to slim down your source, do it prior to launching the program. Again- option "Operating System Options-->Manual Install and Upgrade for removal" must NOT be selected!
!!! Do NOT replace completely WINNT.SIF in ~BT folder when the program completed. If you need to add extra entries- do so, but make sure you don't break what has been done to it. Do NOT add UNATTENDED section, if you need to make these changes in ~LS\I386(AMD64)\tempunat.inf, which contains your unattended section and will be merged at start of GUI mode.
- PE source will be copied as follows:
		everything in I386 copied as MININT
		folder Setup (WinFLPC)
		folder Programs(BartPE) or Program Files(WinBuilder/WinFLPC)
		folder IMAGES (UBCD4Win)
		folder CMDC copied as CMDCONS (UBCD4Win)
		
- Vista/7 source
		entire contents of the selected folder will be copied to root of the selected partition
		
PartedMagic and Syslinux were mentioned above.

- From previous version of USB_multiboot and USB_prepare, undoren.cmd and binifix.cmd(thanks Jaclaz) were merged.

Some still applicable FAQs:
http://www.msfn.org/board/FAQs-t116766.html

Please report bugs(include your log file) or feature requests here:
http://www.msfn.org/board/Install-XP-from-USB-f157.html

When in doubt point your mouse over object in the GUI and read the tooltip, or ask for help in the dedicated MSFN subforum:
http://www.msfn.org/board/Install-XP-USB-f157.html

Have fun :)
