

If you are using windows7:
1) Plug your USB thumb drive in
2) Right click usb_install2_RUNASADMIN.bat, pick Run As Administrator
3) Follow the installation procedure.

Otherwise:
1) Plug your USB thumb drive in
2) Double click (run) on the USB_INSTALL_DIFF.vbs
3) Follow the installation procedure



If you still have some problems with installing Kon-Boot to
USB drive and you are certain that your BIOS supports booting
from USB drive, pelase check following external tutorials:

- http://www.irongeek.com/i.php?page=security/kon-boot-from-usb
- http://www.youtube.com/results?search_query=kon-boot+usb

Obviously please use the .img/.iso files from this package. 