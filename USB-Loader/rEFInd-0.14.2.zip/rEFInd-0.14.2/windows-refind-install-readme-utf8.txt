﻿
1. Скачать архив с дистрибутивом rEFInd
2. Распаковать архив в удобное место
3. Подключить ESP (EFI System Partition)
4. Перенести файлы rEFInd на скрытый, системный, загрузочный раздел EFI.
5. Создать новую папку EFI\Boot и скопировать файлы rEFInd туда. 
6. Переименовать файлы: refind_x64.efi — в bootx64.efi, refind_ia32.efi — в bootia32.efi (для 32-битной версии).
7. Переименовать файл refind.conf-sample в refind.conf. 
8. Указать загрузчику Windows, что нужно по умолчанию загружать rEFInd, с помощью команды bcdedit /set {bootmgr} path "\EFI\refind\refind_x64.efi"
9. Перезагрузить и проверить результат.


mountvol S: S/
cd..
cd..
xcopy /E refind-bin-0.14.2 S:\efi\refind\
S:
cd EFI\refind\refind
rename refind.conf-sample refind.conf
bcdedit /set {bootmgr} path \EFI\refind\refind_x64.efi

