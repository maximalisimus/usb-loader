	This boot disk is provided so that you will be able to reload your 
system if you experience any kind of hard drive or critical operating 
system error.

FDisk:
	**Using this command will allow you to change the partitions of your
hard drive.
1.  Insert this disk in your A: drive.
2.  Load the appropriate drivers for your CD/DVD drive.
3.  At the A:\ prompt type:   fdisk
4.  Choose either Y or N (Y is to enable FAT32 partitioning).
5.  Follow the on-screen instructions.
Note:  You will need to reboot your system before you can format the new 
partitions.

Formatting:
	**To format your hard drive you will need to follow the instructions
below.
1.  Insert this disk in your A: drive.
2.  Load the appropriate drivers for your CD/DVD drive.
3.  At the A:\ prompt type:  format x:  (x being the drive that you wish to
format.  ex. format c:)
Note:  Formatting a hard drive erases ALL data from the drive.


